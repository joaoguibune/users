module.exports = () => {
    var faker = require('faker');
    const data = { users: [] }
    // Create 10 users
    for (let i = 0; i < 10; i++) {
      data.users.push(
        { 
          id: i, 
          first_name: faker.name.firstName(), 
          last_name:faker.name.lastName(),
          email:faker.internet.email(), 
          field: Math.floor(Math.random() * 2) + 1, 
          roles: Math.floor(Math.random() * 2) + 1
        })
    }
    return data
  }