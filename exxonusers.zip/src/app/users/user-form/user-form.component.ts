import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';

import { User } from '../shared/user';
import { UsersService } from '../shared/users.service';
import { BasicValidators } from '../../shared/basic-validators';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.scss']
})
export class UserFormComponent implements OnInit {

  form: FormGroup;
  title: string;
  titleButton: string;
  user: User = new User();
  id: number;

  constructor(
    formBuilder: FormBuilder,
    private router: Router,
    private route: ActivatedRoute,
    private usersService: UsersService
  ) {
    this.form = formBuilder.group({
      first_name: ['', [
        Validators.required,
        Validators.minLength(3)
      ]],
      last_name:['',[
        Validators.required,
        Validators.minLength(3)
      ]],
      email: ['', [
        Validators.required,
        BasicValidators.email
        //Validators.pattern("[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?")
      ]],
      field:['',[
        Validators.required,
        Validators.minLength(3)
      ]],
      roles:['',[
        Validators.required,
        Validators.minLength(3)
      ]],
      
    });
  }

  ngOnInit() {
    var id = this.route.params.subscribe(params => {
      var id = params['id'];
      this.id = id;
      this.title = id ? 'Edit User' : 'New User';
      this.titleButton = id ? 'Save User' : 'Add New User';

      if (!id)
        return;

      this.usersService.getUser(id)
        .subscribe(
          user => this.user = user,
          
          response => {
            if (response.status == 404) {
              this.router.navigate(['NotFound']);
            }
          });
    });

    if(!this.user.field) this.user.field = 1;
    if(!this.user.roles) this.user.roles = 1;
  }

  save() {
    var result,
        
        userId = this.user.id,
        user = this.form.value;
        user.id = userId;
        console.log(this.form.value);
        

    if (this.id){
      result = this.usersService.updateUser(this.form.value);
    } else {
      result = this.usersService.addUser(this.form.value);
    }

    result.subscribe(data => this.router.navigate(['']));
  }
}
