import { RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UsersComponent } from './users.component';
import { UsersService } from './shared/users.service';
import { Ng2SearchPipeModule } from 'ng2-search-filter';
import { UserFormComponent } from './user-form/user-form.component';
import { HttpModule } from '@angular/http';




@NgModule({
  imports: [
    CommonModule,
    Ng2SearchPipeModule,
    FormsModule,
    RouterModule,
    ReactiveFormsModule,
    HttpModule
  ],
  declarations: [
    UsersComponent,
    UserFormComponent,
    
    
  ],
  exports: [
    UsersComponent
  ],
  providers: [
    UsersService
  ]
})
export class UsersModule { }
